package mujina;

import org.junit.Test;

public class MujinaSpApplicationTest {

  @Test
  public void testMain() {
    MujinaSpApplication.main(new String[]{});
  }
}
