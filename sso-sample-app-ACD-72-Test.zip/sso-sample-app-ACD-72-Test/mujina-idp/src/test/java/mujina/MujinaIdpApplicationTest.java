package mujina;

import org.junit.Test;

public class MujinaIdpApplicationTest {

  @Test
  public void testMain() {
    MujinaIdpApplication.main(new String[]{});
  }
}
