package mujina.api;

public enum AuthenticationMethod {
  ALL, USER
}
